import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ProdutoRomaneio, Romaneio } from '../../../models/romaneio';
import { AuthService } from '../../../services/auth.service';
import { RomaneioService } from '../../../services/romaneio.service';

@Component({
  selector: 'app-romaneios-details',
  imports: [CommonModule, FormsModule],
  templateUrl: './romaneios-details.component.html',
  styleUrl: './romaneios-details.component.scss'
})
export class RomaneiosDetailsComponent {
  titulo = 'Cadastrar romaneio';
  romaneio = new Romaneio(0, new Date(), []);
  dataFormulario = this.formatarDataInput(this.romaneio.data);
  nomeProduto = '';
  quantidadeProduto = 1;
  carregando = false;
  salvando = false;
  erro = '';

  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly authService = inject(AuthService);
  private readonly romaneioService = inject(RomaneioService);

  constructor() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    const romaneioRecebido = history.state.romaneio as Romaneio | undefined;

    if (id > 0) {
      this.titulo = 'Editar romaneio';
      if (romaneioRecebido) {
        this.definirRomaneio(romaneioRecebido);
      } else {
        this.carregando = true;
        this.romaneioService.findById(id).subscribe({
          next: romaneioEncontrado => {
            this.definirRomaneio(romaneioEncontrado);
            this.carregando = false;
          },
          error: () => {
            this.carregando = false;
            this.erro = 'Não foi possível carregar o romaneio.';
          }
        });
      }
    }
  }

  adicionarProduto(): void {
    const nome = this.nomeProduto.trim();
    const quantidade = Math.floor(Number(this.quantidadeProduto));
    if (!nome || quantidade < 1) {
      return;
    }

    this.romaneio.produtoList.push({ nome, quantidade });
    this.nomeProduto = '';
    this.quantidadeProduto = 1;
  }

  removerProduto(indice: number): void {
    this.romaneio.produtoList.splice(indice, 1);
  }

  salvar(): void {
    if (this.salvando) {
      return;
    }

    const data = new Date(`${this.dataFormulario}T00:00:00`);
    if (Number.isNaN(data.getTime()) || !this.romaneio.produtoList.length) {
      Swal.fire({
        title: 'Atenção',
        text: 'Informe uma data válida e adicione pelo menos um produto.',
        icon: 'warning',
        confirmButtonText: 'Ok'
      });
      return;
    }

    this.romaneio.data = data;
    this.salvando = true;
    this.erro = '';
    const operacao = this.romaneio.id > 0
      ? this.romaneioService.update(this.romaneio.id, this.romaneio)
      : this.romaneioService.create(this.romaneio);

    operacao.subscribe({
      next: romaneioSalvo => {
        this.romaneio = romaneioSalvo;
        this.salvando = false;
        Swal.fire({
          title: this.romaneio.id > 0 ? 'Editado' : 'Salvo',
          icon: 'success',
          confirmButtonText: 'Ok'
        }).then(() => this.voltar());
      },
      error: () => {
        this.salvando = false;
        this.erro = 'Não foi possível salvar o romaneio.';
        Swal.fire({
          title: 'Não foi possível salvar',
          text: 'O backend recusou o romaneio. Verifique os dados obrigatórios e tente novamente.',
          icon: 'error',
          confirmButtonText: 'Ok'
        });
      }
    });
  }

  voltar(): void {
    this.router.navigate([this.authService.ehAdmin ? '/admin/romaneios' : '/usuario/romaneios']);
  }

  private formatarDataInput(data: Date): string {
    const ano = data.getFullYear();
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const dia = String(data.getDate()).padStart(2, '0');
    return `${ano}-${mes}-${dia}`;
  }

  private definirRomaneio(romaneio: Romaneio): void {
    this.romaneio = new Romaneio(romaneio.id, romaneio.data, romaneio.produtoList || []);
    this.dataFormulario = this.formatarDataInput(this.romaneio.data);
  }
}
