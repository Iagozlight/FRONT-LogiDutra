import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Romaneio } from '../../../models/romaneio';
import { AuthService } from '../../../services/auth.service';
import { RomaneioService } from '../../../services/romaneio.service';

@Component({
  selector: 'app-romaneio-tela-principal',
  imports: [CommonModule],
  templateUrl: './romaneio-tela-principal.component.html',
  styleUrl: './romaneio-tela-principal.component.scss'
})
export class RomaneioTelaPrincipalComponent {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  readonly authService = inject(AuthService);
  private readonly romaneioService = inject(RomaneioService);

  romaneio: Romaneio | null = null;
  carregando = true;
  erro = '';

  constructor() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    const romaneioRecebido = history.state.romaneio as Romaneio | undefined;
    if (romaneioRecebido) {
      this.romaneio = new Romaneio(romaneioRecebido.id, romaneioRecebido.data, romaneioRecebido.produtoList || []);
      this.carregando = false;
    } else {
      this.romaneioService.findById(id).subscribe({
        next: romaneioEncontrado => {
          this.romaneio = romaneioEncontrado;
          this.carregando = false;
        },
        error: () => {
          this.carregando = false;
          this.erro = 'Não foi possível carregar o romaneio.';
        }
      });
    }
  }

  voltar(): void {
    this.router.navigate([this.authService.ehAdmin ? '/admin/romaneios' : '/usuario/romaneios']);
  }
}
